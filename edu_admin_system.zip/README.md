
# Edu Admin System

This is a simple user management system with the ability to edit, delete, and toggle the status (active/block) of users.

## Setup Instructions

1. Ensure you have Node.js installed on your machine.
2. Install the necessary dependencies by running:
   ```
   npm install express body-parser
   ```
3. Run the server with:
   ```
   node app.js
   ```
4. Open the application in your browser by navigating to:
   ```
   http://localhost:3000
   ```

## Files:

1. **app.js**: Node.js server handling user operations.
2. **users.json**: File storing the user data.
3. **index.html**: Frontend HTML for the admin panel.

