
const express = require('express');
const fs = require('fs');
const path = require('path');
const app = express();
const bodyParser = require('body-parser');

// Set up body-parser
app.use(bodyParser.json());

// Path to users file
const usersFile = path.join(__dirname, 'users.json');

// Load users data from the JSON file
function loadUsers() {
  return JSON.parse(fs.readFileSync(usersFile, 'utf-8'));
}

// Save users data to the JSON file
function saveUsers(users) {
  fs.writeFileSync(usersFile, JSON.stringify(users, null, 2), 'utf-8');
}

// API to load all users
app.get('/api/users', (req, res) => {
  const users = loadUsers();
  res.json(users);
});

// API to toggle user status (activate/block)
app.post('/api/users/:id/toggle-status', (req, res) => {
  const users = loadUsers();
  const userId = parseInt(req.params.id);
  const user = users.find(u => u.id === userId);
  
  if (user) {
    user.isActive = !user.isActive; // Toggle the status
    saveUsers(users);
    res.json({ success: true });
  } else {
    res.status(404).send('User not found');
  }
});

// API to delete user
app.delete('/api/users/:id', (req, res) => {
  const users = loadUsers();
  const userId = parseInt(req.params.id);
  const userIndex = users.findIndex(u => u.id === userId);

  if (userIndex !== -1) {
    users.splice(userIndex, 1);
    saveUsers(users);
    res.json({ success: true });
  } else {
    res.status(404).send('User not found');
  }
});

// API for chatting with user
app.get('/admin/chat/:id', (req, res) => {
  // Here you can add logic for a chat feature, such as WebSockets or a separate chat page
  res.send(`Chat with user number ${req.params.id}`);
});

// Start server
const port = 3000;
app.listen(port, () => {
  console.log(`Server running on http://localhost:${port}`);
});
